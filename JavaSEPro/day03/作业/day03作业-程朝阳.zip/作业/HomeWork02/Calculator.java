package com.itheima.HomeWork.HomeWork02;

public interface Calculator {
    int calc(int x,int y);
}
