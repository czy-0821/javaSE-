package com.itheima.HomeWork.HomeWork01;

public interface Director {
    void makeMovie();
}
